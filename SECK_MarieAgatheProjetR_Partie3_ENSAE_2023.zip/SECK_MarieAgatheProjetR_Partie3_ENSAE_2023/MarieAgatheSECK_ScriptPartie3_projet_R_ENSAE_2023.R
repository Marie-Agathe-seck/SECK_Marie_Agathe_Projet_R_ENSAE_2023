#install.packages("rnaturalearthhires", repos = "http://packages.ropensci.org", type = "source")
library(sp)
library(dplyr)
library(shiny)
library(leaflet)
library(rnaturalearth)
library(rnaturalearthdata)
#library(rnaturalearthhires)

# Chargement des données géographiques de l'Afrique de l'Ouest
# afrique_ouest <- subset(ne_countries(scale = "medium", continent = "Africa"), subregion == "Western Africa")
dfshiny <- read.csv("ACLED-Western_Africa.csv")


# Création de l'interface utilisateur
ui <- fluidPage(
  # Titre de l'application
  titlePanel("Carte interactive des pays de l'Afrique de l'Ouest"),
  
  # Sidebar avec les options de filtrage
  sidebarLayout(
    sidebarPanel(
      selectizeInput(
        inputId = "pays",
        label = "Veillez sélectionner un ou plusieurs pays",
        choices = c(unique(dfshiny$pays)),
        selected ="Niger",  # par défaut
        multiple = TRUE
      ),
      selectizeInput(
        inputId = "type_evenement",
        label = "Veillez sélectionnez un ou plusieurs types d'événements",
        choices = c(unique(dfshiny$type)),
        selected = "Protests",
        multiple = TRUE
      ),
      selectizeInput(
        inputId = "annee",
        label = "Veillez sélectionnez une ou plusieurs années",
        choices = c(unique(dfshiny$annee)),
        selected = "2019", # par défaut 
        multiple = TRUE
      )
    ),
    
    # Affichage de la carte Leaflet
    mainPanel(
      leafletOutput(outputId = "carte",
                    width = "100%",
                    height = "720px")
    )
  )
)

# Logique du serveur
server <- function(input, output, session) {
  donnees_filtrees <- reactive({
    donnees_filtrage <- dfshiny %>%
      filter(pays %in% input$pays &
               type %in% input$type_evenement &
               annee %in% input$annee)
    donnees_filtrage
  })
  
  output$carte <- renderLeaflet({
    donnees_filtrage <- donnees_filtrees()
    
    # Création de la carte Leaflet
    carte_leaflet <- leaflet() %>%
      setView(lng = 0, lat = 8, zoom = 4) %>%
      addProviderTiles("Esri.WorldGrayCanvas") %>%
      addPolygons(data = ne_countries(type = "countries", country = input$pays),
                  fillColor = "#00AFBB", color = "black", fillOpacity = 0.6) %>%
      addCircleMarkers(data = donnees_filtrage,
                       lng = ~longitude, lat = ~latitude,
                       radius = 2, fillOpacity = 0.7)
    
    carte_leaflet
  })
}

# Lancement de l'application Shiny
shinyApp(ui = ui, server = server)